﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Intervenientes
{
    public class Pessoa
    {
        // Adicione propriedades e métodos comuns a Doente e Medico, se aplicável
        public string nome { get; set; }
    }
}