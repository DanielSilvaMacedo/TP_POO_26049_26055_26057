var searchData=
[
  ['inseremedicoconsultorio_0',['InsereMedicoConsultorio',['../class_hospital_1_1_consultorio.html#acd99dedd0c49397340b388b8a2e7aa5a',1,'Hospital::Consultorio']]]
];
