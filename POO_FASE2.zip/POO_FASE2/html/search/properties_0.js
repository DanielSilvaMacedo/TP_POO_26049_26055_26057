var searchData=
[
  ['capacidademaxima_0',['capacidadeMaxima',['../class_hospital_1_1_salaa_espera.html#ac5614eb08c619697e40a81169cc85942',1,'Hospital::SalaaEspera']]]
];
