var searchData=
[
  ['salaaespera_0',['SalaaEspera',['../class_hospital_1_1_salaa_espera.html#a74520872538f17854109ab20eed9d8ba',1,'Hospital::SalaaEspera']]],
  ['sistema_1',['Sistema',['../class_hospital_1_1_sistema.html#a3894469576b704cdd592fd76646d8a57',1,'Hospital::Sistema']]]
];
