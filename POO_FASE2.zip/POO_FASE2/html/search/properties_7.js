var searchData=
[
  ['recursosdisponiveis_0',['recursosDisponiveis',['../class_hospital_1_1_salaa_espera.html#a886f14dccab7fed5c8c75804f9a06df4',1,'Hospital::SalaaEspera']]]
];
