var searchData=
[
  ['adicionardoenteconsultorio_0',['AdicionarDoenteConsultorio',['../class_hospital_1_1_consultorio.html#a7ff7a5be940d6b41825503c96b77e0d6',1,'Hospital::Consultorio']]],
  ['adicionardoentesalaespera_1',['AdicionarDoenteSalaEspera',['../class_hospital_1_1_salaa_espera.html#aa6d978fcd73391aa16f586ec7ef67e17',1,'Hospital::SalaaEspera']]],
  ['adicionarmedicoconsultorio_2',['AdicionarMedicoConsultorio',['../class_hospital_1_1_consultorio.html#a4db262b3bedc667ba264a96010b444cd',1,'Hospital::Consultorio']]],
  ['atribuirmedico_3',['AtribuirMedico',['../class_hospital_1_1_sistema.html#abf467dbf5f9102c779285111785784bd',1,'Hospital::Sistema']]],
  ['atualizarhistorico_4',['atualizarhistorico',['../class_hospital_1_1_sistema.html#a983a1a07946458b16ef9602a818e01d9',1,'Hospital.Sistema.AtualizarHistorico()'],['../class_intervenientes_1_1_doente.html#ac7e5f7243126b78689faa963465d7f89',1,'Intervenientes.Doente.AtualizarHistorico()']]]
];
