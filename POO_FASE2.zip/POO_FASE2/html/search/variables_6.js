var searchData=
[
  ['prioridade_0',['prioridade',['../class_intervenientes_1_1_doente.html#a38a93891c032f9c53d7355a154cc501d',1,'Intervenientes::Doente']]],
  ['pulseira_1',['pulseira',['../class_intervenientes_1_1_doente.html#aea04a336104a600bef1261954e323f23',1,'Intervenientes::Doente']]]
];
