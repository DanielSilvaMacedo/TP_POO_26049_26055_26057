var searchData=
[
  ['realizarconsulta_0',['RealizarConsulta',['../class_hospital_1_1_sistema.html#ae95d613ba03543c231bae8c0ad7db3f3',1,'Hospital::Sistema']]],
  ['realizartriagem_1',['RealizarTriagem',['../class_hospital_1_1_sistema.html#a63284134c60bfb5971ee971b911b4fee',1,'Hospital::Sistema']]],
  ['registardoente_2',['RegistarDoente',['../class_hospital_1_1_sistema.html#a25f9d8f2c97a54bde6e66ee6583df7dd',1,'Hospital::Sistema']]],
  ['registarmedico_3',['RegistarMedico',['../class_hospital_1_1_sistema.html#ad15ce8dee799ab8e2dd4eee222c279c2',1,'Hospital::Sistema']]]
];
