var searchData=
[
  ['salaaespera_0',['SalaaEspera',['../class_hospital_1_1_salaa_espera.html',1,'Hospital']]],
  ['sistema_1',['Sistema',['../class_hospital_1_1_sistema.html',1,'Hospital']]]
];
