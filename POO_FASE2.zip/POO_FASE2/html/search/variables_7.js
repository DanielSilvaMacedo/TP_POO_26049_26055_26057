var searchData=
[
  ['sintomas_0',['sintomas',['../class_intervenientes_1_1_doente.html#a364846eb34b05bcdf80ac9b01e320449',1,'Intervenientes::Doente']]]
];
