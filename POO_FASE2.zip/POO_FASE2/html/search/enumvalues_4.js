var searchData=
[
  ['ocupado_0',['OCUPADO',['../namespace_hospital.html#aa9ab2313f208340e2961e7922236403fae2eb5e093b667c2ba1780008fbac7599',1,'Hospital']]],
  ['ortopedia_1',['ORTOPEDIA',['../namespace_intervenientes.html#a99d1979b13bc448f613a0d846b08f22ca448adb9235de9bf4526a6f1e4ad85fc7',1,'Intervenientes']]]
];
