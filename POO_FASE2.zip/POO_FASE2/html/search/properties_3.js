var searchData=
[
  ['historico_0',['Historico',['../class_intervenientes_1_1_doente.html#ac53ad6ead311dc51be425a1c5db89ca4',1,'Intervenientes::Doente']]]
];
