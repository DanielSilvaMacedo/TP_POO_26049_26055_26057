var searchData=
[
  ['consultorio_0',['Consultorio',['../class_hospital_1_1_consultorio.html',1,'Hospital']]]
];
