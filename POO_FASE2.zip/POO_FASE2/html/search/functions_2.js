var searchData=
[
  ['doente_0',['doente',['../class_intervenientes_1_1_doente.html#a555063d9518d1685220187036ff313cc',1,'Intervenientes.Doente.Doente()'],['../class_intervenientes_1_1_doente.html#a7bd0a37ebd470e05723bea13744ba007',1,'Intervenientes.Doente.Doente(int Id, string nome, int nif, int nutente, Pulseira pul, Prioridade pri, string hist, string sint)']]]
];
