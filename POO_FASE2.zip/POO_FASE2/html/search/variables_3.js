var searchData=
[
  ['iddoente_0',['idDoente',['../class_intervenientes_1_1_doente.html#ab045c62c730a2cf29ebb26398f797885',1,'Intervenientes::Doente']]]
];
