var searchData=
[
  ['obterdoentesporprioridade_0',['ObterDoentesPorPrioridade',['../class_hospital_1_1_salaa_espera.html#a5beb42e73d062970a953fecf84490fd2',1,'Hospital::SalaaEspera']]],
  ['obterinformacao_1',['obterinformacao',['../class_hospital_1_1_sistema.html#a24c78fcb66b765978c9730a73dbfa80c',1,'Hospital.Sistema.ObterInformacao()'],['../class_intervenientes_1_1_doente.html#ae465e4c01e9b5964415e7f93080390c9',1,'Intervenientes.Doente.ObterInformacao()']]],
  ['ocupado_2',['OCUPADO',['../namespace_hospital.html#aa9ab2313f208340e2961e7922236403fae2eb5e093b667c2ba1780008fbac7599',1,'Hospital']]],
  ['ortopedia_3',['ORTOPEDIA',['../namespace_intervenientes.html#a99d1979b13bc448f613a0d846b08f22ca448adb9235de9bf4526a6f1e4ad85fc7',1,'Intervenientes']]]
];
