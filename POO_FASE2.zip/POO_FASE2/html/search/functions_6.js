var searchData=
[
  ['obterdoentesporprioridade_0',['ObterDoentesPorPrioridade',['../class_hospital_1_1_salaa_espera.html#a5beb42e73d062970a953fecf84490fd2',1,'Hospital::SalaaEspera']]],
  ['obterinformacao_1',['obterinformacao',['../class_hospital_1_1_sistema.html#a24c78fcb66b765978c9730a73dbfa80c',1,'Hospital.Sistema.ObterInformacao()'],['../class_intervenientes_1_1_doente.html#ae465e4c01e9b5964415e7f93080390c9',1,'Intervenientes.Doente.ObterInformacao()']]]
];
