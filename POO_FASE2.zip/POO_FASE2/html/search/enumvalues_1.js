var searchData=
[
  ['cardiologia_0',['CARDIOLOGIA',['../namespace_intervenientes.html#a99d1979b13bc448f613a0d846b08f22ca0035462a4c1b8b6828fc64cd44a01930',1,'Intervenientes']]],
  ['cirugia_1',['CIRUGIA',['../namespace_intervenientes.html#a99d1979b13bc448f613a0d846b08f22caca18844ffdb79cb0d4fb56257ab10e45',1,'Intervenientes']]]
];
