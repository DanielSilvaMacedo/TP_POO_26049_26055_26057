var searchData=
[
  ['vazio_0',['VAZIO',['../namespace_hospital.html#aa9ab2313f208340e2961e7922236403fa1205e40569037712b104f12cb4534293',1,'Hospital']]],
  ['verde_1',['VERDE',['../namespace_intervenientes.html#a601d87bf65cc835ed3a85592c5c8c2bcac57b8e9ffb37b1384e9299cd12886fdb',1,'Intervenientes']]],
  ['vermelha_2',['VERMELHA',['../namespace_intervenientes.html#a601d87bf65cc835ed3a85592c5c8c2bca37cd69d37b20da810cf48888a53db944',1,'Intervenientes']]]
];
