var searchData=
[
  ['iddoente_0',['IdDoente',['../class_intervenientes_1_1_doente.html#aba4907252dbf9bd6b3ec67f2b1730f5b',1,'Intervenientes::Doente']]]
];
