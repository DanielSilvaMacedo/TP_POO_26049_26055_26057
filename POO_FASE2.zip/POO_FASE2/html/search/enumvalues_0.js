var searchData=
[
  ['amarela_0',['AMARELA',['../namespace_intervenientes.html#a601d87bf65cc835ed3a85592c5c8c2bca774b346648a7ecb513931ecec03be458',1,'Intervenientes']]]
];
