var searchData=
[
  ['capacidademaxima_0',['capacidadeMaxima',['../class_hospital_1_1_salaa_espera.html#ac5614eb08c619697e40a81169cc85942',1,'Hospital::SalaaEspera']]],
  ['cardiologia_1',['CARDIOLOGIA',['../namespace_intervenientes.html#a99d1979b13bc448f613a0d846b08f22ca0035462a4c1b8b6828fc64cd44a01930',1,'Intervenientes']]],
  ['cirugia_2',['CIRUGIA',['../namespace_intervenientes.html#a99d1979b13bc448f613a0d846b08f22caca18844ffdb79cb0d4fb56257ab10e45',1,'Intervenientes']]],
  ['consultorio_3',['consultorio',['../class_hospital_1_1_consultorio.html',1,'Hospital.Consultorio'],['../class_hospital_1_1_consultorio.html#a09dfa05b94dd85c8843706d2d09cd59c',1,'Hospital.Consultorio.Consultorio()'],['../class_hospital_1_1_consultorio.html#a8cafc8fd28acf784cf3cc7a9ff4201fe',1,'Hospital.Consultorio.Consultorio(int num, Especialidade esp, Estado est, Medico medico, Doente doente)']]],
  ['consultorio_2ecs_4',['Consultorio.cs',['../_consultorio_8cs.html',1,'']]],
  ['contardoentes_5',['ContarDoentes',['../class_hospital_1_1_salaa_espera.html#a15282388971f8e35ba483d8cfff289ef',1,'Hospital::SalaaEspera']]]
];
