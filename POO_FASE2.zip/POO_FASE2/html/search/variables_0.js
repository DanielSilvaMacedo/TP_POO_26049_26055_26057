var searchData=
[
  ['doenteconsultorio_0',['doenteConsultorio',['../class_hospital_1_1_consultorio.html#a84877f1ce4625bf43e3a6607e7ba5243',1,'Hospital::Consultorio']]]
];
