var searchData=
[
  ['especialidade_0',['especialidade',['../class_intervenientes_1_1_medico.html#adcfdb449145bda39ba5c706ab2a3aff2',1,'Intervenientes::Medico']]]
];
