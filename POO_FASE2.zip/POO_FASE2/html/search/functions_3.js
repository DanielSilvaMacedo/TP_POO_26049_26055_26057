var searchData=
[
  ['encaminharparasalaespera_0',['EncaminharParaSalaEspera',['../class_hospital_1_1_sistema.html#afed9863d9b2955c6daf901cc340ddff5',1,'Hospital::Sistema']]],
  ['existedoenteconsultorio_1',['ExisteDoenteConsultorio',['../class_hospital_1_1_consultorio.html#a600b26941e6e7c9523db6e28542a012d',1,'Hospital::Consultorio']]],
  ['existedoentesalaespera_2',['ExisteDoenteSalaEspera',['../class_hospital_1_1_salaa_espera.html#aa4dd67547e19fd6c8d398efa4a5823cb',1,'Hospital::SalaaEspera']]],
  ['existemedicoconsultorio_3',['ExisteMedicoConsultorio',['../class_hospital_1_1_consultorio.html#ae98d3cbb034ed7cb2ddde36dbda9bb39',1,'Hospital::Consultorio']]]
];
