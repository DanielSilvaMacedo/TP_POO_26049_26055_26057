var searchData=
[
  ['nif_0',['Nif',['../class_intervenientes_1_1_doente.html#a58b1b98abe1936044355ca99af20462c',1,'Intervenientes::Doente']]],
  ['nifentificacao_1',['NIfentificacao',['../class_intervenientes_1_1_medico.html#a696855ed90f3e89365851330124e4152',1,'Intervenientes::Medico']]],
  ['nome_2',['nome',['../class_intervenientes_1_1_pessoa.html#acba662422dae1ac6a58c894d4e32c6c4',1,'Intervenientes.Pessoa.nome'],['../class_intervenientes_1_1_doente.html#a3b027464b5a85720c55dcd15dd574709',1,'Intervenientes.Doente.Nome'],['../class_intervenientes_1_1_medico.html#a5e2e2b69d7eb8694fd9ca157aaac5a90',1,'Intervenientes.Medico.Nome']]],
  ['numero_3',['Numero',['../class_hospital_1_1_consultorio.html#a4b6f0022cd0889d6ae4ae3690dd89a5f',1,'Hospital::Consultorio']]],
  ['nutente_4',['Nutente',['../class_intervenientes_1_1_doente.html#ab079a272a4183930951244ce0c8b64d9',1,'Intervenientes::Doente']]]
];
