var searchData=
[
  ['pediatria_0',['PEDIATRIA',['../namespace_intervenientes.html#a99d1979b13bc448f613a0d846b08f22cac8de40f42c422f54aaf3a6e6d9cb79c6',1,'Intervenientes']]],
  ['pouco_5furgente_1',['POUCO_URGENTE',['../namespace_intervenientes.html#ab94719e1831dafef5994f03b2f6e0a09aa681e1616a3b2bb41e993198ea6c7057',1,'Intervenientes']]]
];
