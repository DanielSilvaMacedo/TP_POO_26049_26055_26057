var searchData=
[
  ['medico_0',['medico',['../class_intervenientes_1_1_medico.html#adc246f8f48d3d9c1c8814292fb7764fb',1,'Intervenientes.Medico.Medico()'],['../class_intervenientes_1_1_medico.html#a548a6f1b4b802e3a9a1c37c4f41678f1',1,'Intervenientes.Medico.Medico(string nome, Especialidade esp, int nidentificacao)']]],
  ['mostrarlugaresocupados_1',['MostrarLugaresOcupados',['../class_hospital_1_1_salaa_espera.html#a7e0b941798bcceec9996f73cd4dcdc20',1,'Hospital::SalaaEspera']]]
];
