var searchData=
[
  ['sintomas_0',['Sintomas',['../class_intervenientes_1_1_doente.html#ac4ab28c2e215c263a15f032778df98ef',1,'Intervenientes::Doente']]]
];
