var searchData=
[
  ['historico_0',['historico',['../class_intervenientes_1_1_doente.html#a75c7d31b8b39cbfa4a2d4c1d38b7b155',1,'Intervenientes::Doente']]]
];
