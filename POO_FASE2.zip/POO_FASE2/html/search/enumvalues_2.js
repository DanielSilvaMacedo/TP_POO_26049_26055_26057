var searchData=
[
  ['muito_5furgente_0',['MUITO_URGENTE',['../namespace_intervenientes.html#ab94719e1831dafef5994f03b2f6e0a09acd97bebf69394a150faf47bdf7885e2b',1,'Intervenientes']]]
];
