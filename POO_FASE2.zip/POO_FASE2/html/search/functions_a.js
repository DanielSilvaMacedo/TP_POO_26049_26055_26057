var searchData=
[
  ['tostring_0',['tostring',['../class_intervenientes_1_1_doente.html#a9bfece2d81d16bad671303d38a872fee',1,'Intervenientes.Doente.ToString()'],['../class_intervenientes_1_1_medico.html#a24de38bc852c2dc435fda29dc20d28d8',1,'Intervenientes.Medico.ToString()']]]
];
