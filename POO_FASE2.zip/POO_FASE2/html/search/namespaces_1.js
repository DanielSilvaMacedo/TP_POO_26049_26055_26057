var searchData=
[
  ['hospital_0',['Hospital',['../namespace_hospital.html',1,'']]]
];
