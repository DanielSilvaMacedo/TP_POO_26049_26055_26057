var searchData=
[
  ['nao_5fespecificada_0',['nao_especificada',['../namespace_intervenientes.html#a601d87bf65cc835ed3a85592c5c8c2bca311895b3dec517edf77b65bce2419dd2',1,'Intervenientes.NAO_ESPECIFICADA'],['../namespace_intervenientes.html#a99d1979b13bc448f613a0d846b08f22ca311895b3dec517edf77b65bce2419dd2',1,'Intervenientes.NAO_ESPECIFICADA']]],
  ['nao_5fespecificado_1',['NAO_ESPECIFICADO',['../namespace_intervenientes.html#ab94719e1831dafef5994f03b2f6e0a09a3558293e0931f88888c1c0ea2665a010',1,'Intervenientes']]]
];
