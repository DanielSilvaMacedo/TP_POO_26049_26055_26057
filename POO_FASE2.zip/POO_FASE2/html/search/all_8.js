var searchData=
[
  ['local_0',['Local',['../class_hospital_1_1_local.html',1,'Hospital']]],
  ['local_2ecs_1',['Local.cs',['../_local_8cs.html',1,'']]]
];
