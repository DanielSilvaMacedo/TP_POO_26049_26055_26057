var searchData=
[
  ['local_0',['Local',['../class_hospital_1_1_local.html',1,'Hospital']]]
];
