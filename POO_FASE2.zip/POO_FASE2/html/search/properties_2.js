var searchData=
[
  ['especialidade_0',['especialidade',['../class_hospital_1_1_consultorio.html#a10c5d2219e8777ef9e242e9596f6cc29',1,'Hospital.Consultorio.Especialidade'],['../class_intervenientes_1_1_medico.html#a5c340ba79edd0bc05607b16ba7b1dc32',1,'Intervenientes.Medico.Especialidade']]],
  ['estado_1',['estado',['../class_hospital_1_1_consultorio.html#af97368865090241e4e83a18354b4c429',1,'Hospital.Consultorio.Estado'],['../class_hospital_1_1_local.html#a4a7df3f10d4cd4042a8a7b6f48541361',1,'Hospital.Local.estado']]]
];
