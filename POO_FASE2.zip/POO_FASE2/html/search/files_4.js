var searchData=
[
  ['hospital_2eassemblyinfo_2ecs_0',['Hospital.AssemblyInfo.cs',['../_hospital_8_assembly_info_8cs.html',1,'']]],
  ['hospital_2eglobalusings_2eg_2ecs_1',['Hospital.GlobalUsings.g.cs',['../_hospital_8_global_usings_8g_8cs.html',1,'']]]
];
