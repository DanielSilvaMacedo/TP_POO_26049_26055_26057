var searchData=
[
  ['historico_0',['historico',['../class_intervenientes_1_1_doente.html#a75c7d31b8b39cbfa4a2d4c1d38b7b155',1,'Intervenientes.Doente.historico'],['../class_intervenientes_1_1_doente.html#ac53ad6ead311dc51be425a1c5db89ca4',1,'Intervenientes.Doente.Historico']]],
  ['hospital_1',['Hospital',['../namespace_hospital.html',1,'']]],
  ['hospital_2eassemblyinfo_2ecs_2',['Hospital.AssemblyInfo.cs',['../_hospital_8_assembly_info_8cs.html',1,'']]],
  ['hospital_2eglobalusings_2eg_2ecs_3',['Hospital.GlobalUsings.g.cs',['../_hospital_8_global_usings_8g_8cs.html',1,'']]]
];
