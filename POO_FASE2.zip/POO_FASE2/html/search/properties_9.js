var searchData=
[
  ['totcon_0',['TotCon',['../class_hospital_1_1_consultorio.html#a871a77284f9f3e60b6339012840b30dc',1,'Hospital::Consultorio']]],
  ['totdoe_1',['TotDoe',['../class_intervenientes_1_1_doente.html#a2e908963e9e78d278d283e965a673a28',1,'Intervenientes::Doente']]],
  ['totmed_2',['TotMed',['../class_intervenientes_1_1_medico.html#a1e89e8ac914c9bca0cd7c064c3a76372',1,'Intervenientes::Medico']]]
];
