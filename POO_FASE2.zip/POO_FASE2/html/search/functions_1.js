var searchData=
[
  ['consultorio_0',['consultorio',['../class_hospital_1_1_consultorio.html#a09dfa05b94dd85c8843706d2d09cd59c',1,'Hospital.Consultorio.Consultorio()'],['../class_hospital_1_1_consultorio.html#a8cafc8fd28acf784cf3cc7a9ff4201fe',1,'Hospital.Consultorio.Consultorio(int num, Especialidade esp, Estado est, Medico medico, Doente doente)']]],
  ['contardoentes_1',['ContarDoentes',['../class_hospital_1_1_salaa_espera.html#a15282388971f8e35ba483d8cfff289ef',1,'Hospital::SalaaEspera']]]
];
