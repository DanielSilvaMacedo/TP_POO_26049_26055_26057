var searchData=
[
  ['tostring_0',['tostring',['../class_intervenientes_1_1_doente.html#a9bfece2d81d16bad671303d38a872fee',1,'Intervenientes.Doente.ToString()'],['../class_intervenientes_1_1_medico.html#a24de38bc852c2dc435fda29dc20d28d8',1,'Intervenientes.Medico.ToString()']]],
  ['totcon_1',['TotCon',['../class_hospital_1_1_consultorio.html#a871a77284f9f3e60b6339012840b30dc',1,'Hospital::Consultorio']]],
  ['totdoe_2',['TotDoe',['../class_intervenientes_1_1_doente.html#a2e908963e9e78d278d283e965a673a28',1,'Intervenientes::Doente']]],
  ['totmed_3',['TotMed',['../class_intervenientes_1_1_medico.html#a1e89e8ac914c9bca0cd7c064c3a76372',1,'Intervenientes::Medico']]]
];
