var searchData=
[
  ['_2enetcoreapp_2cversion_3dv8_2e0_2eassemblyattributes_2ecs_0',['.netcoreapp,version=v8.0.assemblyattributes.cs',['../_hospital_2obj_2_debug_2net8_80_2_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html',1,'(Namespace global)'],['../_intervenientes_2obj_2_debug_2net8_80_2_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html',1,'(Namespace global)']]],
  ['_2enetframework_2cversion_3dv4_2e7_2e2_2eassemblyattributes_2ecs_1',['.NETFramework,Version=v4.7.2.AssemblyAttributes.cs',['../_8_n_e_t_framework_00_version_0av4_87_82_8_assembly_attributes_8cs.html',1,'']]]
];
