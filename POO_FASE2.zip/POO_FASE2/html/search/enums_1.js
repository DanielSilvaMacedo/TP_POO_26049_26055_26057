var searchData=
[
  ['prioridade_0',['Prioridade',['../namespace_intervenientes.html#ab94719e1831dafef5994f03b2f6e0a09',1,'Intervenientes']]],
  ['pulseira_1',['Pulseira',['../namespace_intervenientes.html#a601d87bf65cc835ed3a85592c5c8c2bc',1,'Intervenientes']]]
];
