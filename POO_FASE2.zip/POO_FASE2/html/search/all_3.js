var searchData=
[
  ['doente_0',['doente',['../class_intervenientes_1_1_doente.html',1,'Intervenientes.Doente'],['../class_intervenientes_1_1_doente.html#a555063d9518d1685220187036ff313cc',1,'Intervenientes.Doente.Doente()'],['../class_intervenientes_1_1_doente.html#a7bd0a37ebd470e05723bea13744ba007',1,'Intervenientes.Doente.Doente(int Id, string nome, int nif, int nutente, Pulseira pul, Prioridade pri, string hist, string sint)'],['../class_hospital_1_1_salaa_espera.html#abcfce52f4b45995ed22b82e9c832f0e7',1,'Hospital.SalaaEspera.doente']]],
  ['doente_2ecs_1',['Doente.cs',['../_doente_8cs.html',1,'']]],
  ['doenteconsultorio_2',['doenteConsultorio',['../class_hospital_1_1_consultorio.html#a84877f1ce4625bf43e3a6607e7ba5243',1,'Hospital::Consultorio']]]
];
