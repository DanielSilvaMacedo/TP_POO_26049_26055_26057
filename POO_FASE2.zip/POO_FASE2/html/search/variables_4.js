var searchData=
[
  ['medicoresponsavel_0',['medicoResponsavel',['../class_hospital_1_1_consultorio.html#a510f29d0ac3d5266e3ec22d6b5401810',1,'Hospital::Consultorio']]]
];
