var searchData=
[
  ['medico_0',['Medico',['../class_intervenientes_1_1_medico.html',1,'Intervenientes']]]
];
