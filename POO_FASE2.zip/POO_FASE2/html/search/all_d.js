var searchData=
[
  ['quantosdoentesexistemsalaespera_0',['QuantosDoentesExistemSalaEspera',['../class_hospital_1_1_salaa_espera.html#aac89e563d6d0bb1fdae5389283a8af2f',1,'Hospital::SalaaEspera']]]
];
