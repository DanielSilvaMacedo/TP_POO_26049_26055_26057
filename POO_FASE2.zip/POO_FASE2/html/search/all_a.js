var searchData=
[
  ['nao_5fespecificada_0',['nao_especificada',['../namespace_intervenientes.html#a601d87bf65cc835ed3a85592c5c8c2bca311895b3dec517edf77b65bce2419dd2',1,'Intervenientes.NAO_ESPECIFICADA'],['../namespace_intervenientes.html#a99d1979b13bc448f613a0d846b08f22ca311895b3dec517edf77b65bce2419dd2',1,'Intervenientes.NAO_ESPECIFICADA']]],
  ['nao_5fespecificado_1',['NAO_ESPECIFICADO',['../namespace_intervenientes.html#ab94719e1831dafef5994f03b2f6e0a09a3558293e0931f88888c1c0ea2665a010',1,'Intervenientes']]],
  ['nidentificacao_2',['nidentificacao',['../class_intervenientes_1_1_medico.html#a0189b3751d5f555a312c4b68d15ef44e',1,'Intervenientes::Medico']]],
  ['nif_3',['nif',['../class_intervenientes_1_1_doente.html#ab7bf4982c8822b78a05510b83b8a9f37',1,'Intervenientes.Doente.nif'],['../class_intervenientes_1_1_doente.html#a58b1b98abe1936044355ca99af20462c',1,'Intervenientes.Doente.Nif']]],
  ['nifentificacao_4',['NIfentificacao',['../class_intervenientes_1_1_medico.html#a696855ed90f3e89365851330124e4152',1,'Intervenientes::Medico']]],
  ['nome_5',['nome',['../class_intervenientes_1_1_pessoa.html#acba662422dae1ac6a58c894d4e32c6c4',1,'Intervenientes.Pessoa.nome'],['../class_intervenientes_1_1_doente.html#a3b027464b5a85720c55dcd15dd574709',1,'Intervenientes.Doente.Nome'],['../class_intervenientes_1_1_medico.html#a5e2e2b69d7eb8694fd9ca157aaac5a90',1,'Intervenientes.Medico.Nome']]],
  ['numero_6',['numero',['../class_hospital_1_1_consultorio.html#a305eb14e52c73906cb191ad11e2036ed',1,'Hospital.Consultorio.numero'],['../class_hospital_1_1_consultorio.html#a4b6f0022cd0889d6ae4ae3690dd89a5f',1,'Hospital.Consultorio.Numero']]],
  ['nutente_7',['nutente',['../class_intervenientes_1_1_doente.html#ad26bc00649ccb410dc6383423f124d91',1,'Intervenientes.Doente.nutente'],['../class_intervenientes_1_1_doente.html#ab079a272a4183930951244ce0c8b64d9',1,'Intervenientes.Doente.Nutente']]]
];
