var searchData=
[
  ['salaaespera_0',['salaaespera',['../class_hospital_1_1_salaa_espera.html',1,'Hospital.SalaaEspera'],['../class_hospital_1_1_salaa_espera.html#a74520872538f17854109ab20eed9d8ba',1,'Hospital.SalaaEspera.SalaaEspera()']]],
  ['salaaespera_2ecs_1',['SalaaEspera.cs',['../_salaa_espera_8cs.html',1,'']]],
  ['sintomas_2',['sintomas',['../class_intervenientes_1_1_doente.html#a364846eb34b05bcdf80ac9b01e320449',1,'Intervenientes.Doente.sintomas'],['../class_intervenientes_1_1_doente.html#ac4ab28c2e215c263a15f032778df98ef',1,'Intervenientes.Doente.Sintomas']]],
  ['sistema_3',['sistema',['../class_hospital_1_1_sistema.html',1,'Hospital.Sistema'],['../class_hospital_1_1_sistema.html#a3894469576b704cdd592fd76646d8a57',1,'Hospital.Sistema.Sistema()']]],
  ['sistema_2ecs_4',['Sistema.cs',['../_sistema_8cs.html',1,'']]]
];
