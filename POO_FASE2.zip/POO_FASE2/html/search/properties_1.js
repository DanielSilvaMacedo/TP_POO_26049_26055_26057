var searchData=
[
  ['doente_0',['doente',['../class_hospital_1_1_salaa_espera.html#abcfce52f4b45995ed22b82e9c832f0e7',1,'Hospital::SalaaEspera']]]
];
