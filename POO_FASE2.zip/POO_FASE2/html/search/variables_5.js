var searchData=
[
  ['nidentificacao_0',['nidentificacao',['../class_intervenientes_1_1_medico.html#a0189b3751d5f555a312c4b68d15ef44e',1,'Intervenientes::Medico']]],
  ['nif_1',['nif',['../class_intervenientes_1_1_doente.html#ab7bf4982c8822b78a05510b83b8a9f37',1,'Intervenientes::Doente']]],
  ['numero_2',['numero',['../class_hospital_1_1_consultorio.html#a305eb14e52c73906cb191ad11e2036ed',1,'Hospital::Consultorio']]],
  ['nutente_3',['nutente',['../class_intervenientes_1_1_doente.html#ad26bc00649ccb410dc6383423f124d91',1,'Intervenientes::Doente']]]
];
