var searchData=
[
  ['prioridade_0',['Prioridade',['../class_intervenientes_1_1_doente.html#ad539ada1469cda846487903cf8a74c4a',1,'Intervenientes::Doente']]],
  ['pulseira_1',['Pulseira',['../class_intervenientes_1_1_doente.html#afbbe77e426d7aa5e11fab65cf86a8024',1,'Intervenientes::Doente']]]
];
